from distutils.core import setup

setup(
    name='Kwrawler',
    version='0.1dev',
    packages=['kwrawler',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)
